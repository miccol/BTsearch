class NodeStatus:
    Success,Failure,Running,Idle = range(4)

class NodeColor:
    Gray,Red,Green,Black = range(4)


