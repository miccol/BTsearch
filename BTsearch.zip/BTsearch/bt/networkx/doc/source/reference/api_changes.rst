***********
API changes
***********

.. toctree::
   :maxdepth: 2

   release_2.0
   api_1.10
   api_1.9
   api_1.8
   api_1.7
   api_1.6
   api_1.5
   api_1.4
   api_1.0
   api_0.99
